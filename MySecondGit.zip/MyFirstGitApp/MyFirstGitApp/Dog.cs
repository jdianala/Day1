﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;

namespace MyFirstGitApp
{
    class Dog
    {
        // lbs
        public int weight = 100;
        public string color = "brown";



        public void Bark ()
        {
            Console.WriteLine("Woof");
           
        }

        public void Send(MailMessage message)
        {

        }
    }
}

/* JavaScript Equivalent

 


    */