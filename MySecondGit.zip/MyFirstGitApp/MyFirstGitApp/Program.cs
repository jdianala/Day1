﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MyFirstGitApp
{
    class Program
    {
       /* static void Main(string[] args)
        {
            if( File.Exists(@"C:\HellowWorld.txt"))// @ symbol turns off escape tags like /t
            {
                Console.WriteLine(@"It Exists!");               
            }
            else
            {
                Console.WriteLine(@"It Does Not Exists!");
               
            }

            Console.ReadLine();

        }
        */
    }
}
