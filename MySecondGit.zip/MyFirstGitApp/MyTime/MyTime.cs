﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace MyFirstGitApp
{
    class MyTime
    {
        public static void Main()
        {
            Console.WriteLine(DateTime.Now);
            Console.ReadLine();
        }
    }
}
